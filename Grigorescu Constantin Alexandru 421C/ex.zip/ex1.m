function ex1()
  
  a=[1:0.1:2]
  b=ones([length(a),1])%b are lungimea lui a
  a*b%suma numerelor
  b*a
  c=a.*b%rezultatul este tot a
  
endfunction
